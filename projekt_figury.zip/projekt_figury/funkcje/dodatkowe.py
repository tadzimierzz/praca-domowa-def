import math


def dodatkowe() -> None:
    while True:
        print("\\n--- DODATKOWE WZORY ---")
        print("a - przekątna kwadratu")
        print("b - wysokość trójkąta równobocznego")
        print("c - twierdzenie Pitagorasa: oblicz przeciwprostokątną")
        print("x - powrót do menu głównego")

        inp = input("Wybierz: ").lower().strip()

        if inp == "a":
            a = float(input("Podaj bok kwadratu a: "))
            print("Przekątna d =", a * math.sqrt(2))

        elif inp == "b":
            a = float(input("Podaj bok trójkąta a: "))
            print("Wysokość h =", a * math.sqrt(3) / 2)

        elif inp == "c":
            a = float(input("Podaj przyprostokątną a: "))
            b = float(input("Podaj przyprostokątną b: "))
            print("Przeciwprostokątna c =", math.sqrt(a ** 2 + b ** 2))

        elif inp == "x":
            break

        else:
            print("Nie ma takiej komendy.")
