import math


def bryly() -> None:
    while True:
        print("\\n--- BRYŁY ---")
        print("a - sześcian")
        print("b - prostopadłościan")
        print("c - graniastosłup")
        print("d - ostrosłup")
        print("e - walec")
        print("f - stożek")
        print("g - kula")
        print("x - powrót do menu głównego")

        inp = input("Wybierz bryłę: ").lower().strip()

        if inp == "a":
            a = float(input("Podaj krawędź a: "))
            print("Pole powierzchni =", 6 * a ** 2)
            print("Objętość =", a ** 3)

        elif inp == "b":
            a = float(input("Podaj a: "))
            b = float(input("Podaj b: "))
            c = float(input("Podaj c: "))
            print("Pole powierzchni =", 2*a*b + 2*a*c + 2*b*c)
            print("Objętość =", a*b*c)

        elif inp == "c":
            pp = float(input("Podaj pole podstawy Pp: "))
            obwod = float(input("Podaj obwód podstawy: "))
            h = float(input("Podaj wysokość H: "))
            pb = float(input("Podaj pole powierzchni bocznej Pb: "))
            print("Pole powierzchni =", 2 * pp + pb)
            print("Objętość =", pp * h)
            print("Uwaga: Pb oznacza pole powierzchni bocznej.")

        elif inp == "d":
            pp = float(input("Podaj pole podstawy Pp: "))
            h = float(input("Podaj wysokość H: "))
            pb = float(input("Podaj pole powierzchni bocznej Pb: "))
            print("Pole powierzchni =", pp + pb)
            print("Objętość =", (pp * h) / 3)
            print("Uwaga: Pb oznacza pole powierzchni bocznej.")

        elif inp == "e":
            r = float(input("Podaj promień r: "))
            h = float(input("Podaj wysokość H: "))
            print("Pole powierzchni =", 2 * math.pi * r ** 2 + 2 * math.pi * r * h)
            print("Objętość =", math.pi * r ** 2 * h)

        elif inp == "f":
            r = float(input("Podaj promień r: "))
            h = float(input("Podaj wysokość H: "))
            l = float(input("Podaj tworzącą l: "))
            print("Pole powierzchni =", math.pi * r ** 2 + math.pi * r * l)
            print("Objętość =", (math.pi * r ** 2 * h) / 3)

        elif inp == "g":
            r = float(input("Podaj promień r: "))
            print("Pole powierzchni =", 4 * math.pi * r ** 2)
            print("Objętość =", (4 * math.pi * r ** 3) / 3)

        elif inp == "x":
            break

        else:
            print("Nie ma takiej bryły.")
