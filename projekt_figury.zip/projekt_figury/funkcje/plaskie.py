import math


def plaskie() -> None:
    while True:
        print("\\n--- FIGURY PŁASKIE ---")
        print("a - kwadrat")
        print("b - prostokąt")
        print("c - równoległobok")
        print("d - trapez")
        print("e - trójkąt")
        print("f - trójkąt równoboczny")
        print("g - koło")
        print("h - romb")
        print("x - powrót do menu głównego")

        inp = input("Wybierz figurę: ").lower().strip()

        if inp == "a":
            a = float(input("Podaj bok a: "))
            print("Obwód =", 4 * a)
            print("Pole =", a ** 2)

        elif inp == "b":
            a = float(input("Podaj bok a: "))
            b = float(input("Podaj bok b: "))
            print("Obwód =", 2 * a + 2 * b)
            print("Pole =", a * b)

        elif inp == "c":
            a = float(input("Podaj bok a: "))
            b = float(input("Podaj bok b: "))
            h = float(input("Podaj wysokość h: "))
            print("Obwód =", 2 * a + 2 * b)
            print("Pole =", a * h)

        elif inp == "d":
            a = float(input("Podaj podstawę a: "))
            b = float(input("Podaj podstawę b: "))
            c = float(input("Podaj bok c: "))
            d = float(input("Podaj bok d: "))
            h = float(input("Podaj wysokość h: "))
            print("Obwód =", a + b + c + d)
            print("Pole =", ((a + b) * h) / 2)

        elif inp == "e":
            a = float(input("Podaj bok a: "))
            b = float(input("Podaj bok b: "))
            c = float(input("Podaj podstawę c: "))
            h = float(input("Podaj wysokość do podstawy c: "))
            print("Obwód =", a + b + c)
            print("Pole =", (c * h) / 2)

        elif inp == "f":
            a = float(input("Podaj bok a: "))
            print("Obwód =", 3 * a)
            print("Pole =", (a ** 2 * math.sqrt(3)) / 4)
            print("Wysokość =", (a * math.sqrt(3)) / 2)

        elif inp == "g":
            r = float(input("Podaj promień r: "))
            print("Obwód koła =", 2 * math.pi * r)
            print("Pole koła =", math.pi * r ** 2)

        elif inp == "h":
            a = float(input("Podaj bok a: "))
            h = float(input("Podaj wysokość h: "))
            print("Obwód =", 4 * a)
            print("Pole =", a * h)
            print("Można też obliczyć pole z przekątnych: P = (e * f) / 2")

        elif inp == "x":
            break

        else:
            print("Nie ma takiej figury.")
