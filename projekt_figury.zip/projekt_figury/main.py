import funkcje.plaskie as pl
import funkcje.bryly as br
import funkcje.dodatkowe as dod


def legenda() -> None:
    print("\\n--- MENU GŁÓWNE ---")
    print("a - bryły")
    print("b - figury płaskie")
    print("c - dodatkowe wzory")
    print("e - wyjdź z programu")


def main() -> None:
    while True:
        legenda()
        inp = input("Wybierz: ").lower().strip()

        if inp == "a":
            br.bryly()
        elif inp == "b":
            pl.plaskie()
        elif inp == "c":
            dod.dodatkowe()
        elif inp == "e":
            print("Program zakończył działanie.")
            break
        else:
            print("Nie ma takiej komendy.")


# ---------------------------------------------
main()
